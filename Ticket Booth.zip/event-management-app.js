import React, { useState, useEffect, createContext, useContext } from 'react';
import ReactDOM from 'react-dom';

// ============================================================================
// CONTEXT & STATE MANAGEMENT
// ============================================================================

const AppContext = createContext();
const useAppContext = () => useContext(AppContext);

const AppProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [events, setEvents] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [activities, setActivities] = useState([]);
  const [users, setUsers] = useState([]);
  const [currentPage, setCurrentPage] = useState('home');
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(false);

  const logActivity = (action, details) => {
    const activity = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toLocaleString(),
      userId: user?.id || 'anonymous',
      action,
      details,
    };
    setActivities(prev => [activity, ...prev]);
  };

  const register = (email, password, name) => {
    const newUser = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      password,
      name,
      createdAt: new Date().toLocaleString(),
    };
    setUsers(prev => [...prev, newUser]);
    setUser(newUser);
    logActivity('USER_REGISTERED', { email, name });
  };

  const login = (email, password) => {
    const foundUser = users.find(u => u.email === email && u.password === password);
    if (foundUser) {
      setUser(foundUser);
      setIsAdmin(foundUser.email === 'admin@events.com');
      logActivity('USER_LOGIN', { email });
      return true;
    }
    return false;
  };

  const logout = () => {
    logActivity('USER_LOGOUT', { email: user?.email });
    setUser(null);
    setIsAdmin(false);
    setCurrentPage('home');
  };

  const createEvent = (eventData) => {
    const newEvent = {
      id: Math.random().toString(36).substr(2, 9),
      ...eventData,
      createdBy: user?.id,
      createdAt: new Date().toLocaleString(),
      ticketsSold: 0,
    };
    setEvents(prev => [...prev, newEvent]);
    logActivity('EVENT_CREATED', { eventName: eventData.title });
    return newEvent;
  };

  const bookTicket = (eventId, quantity) => {
    const event = events.find(e => e.id === eventId);
    if (!event || event.ticketsSold + quantity > event.capacity) return null;

    const bookingId = Math.random().toString(36).substr(2, 9);
    const newBooking = {
      id: bookingId,
      eventId,
      userId: user.id,
      quantity,
      bookingDate: new Date().toLocaleString(),
      tickets: Array.from({ length: quantity }, (_, i) => ({
        qrCode: `TICKET-${bookingId}-${i + 1}`,
        status: 'valid',
      })),
      totalPrice: event.price * quantity,
    };

    setBookings(prev => [...prev, newBooking]);
    setEvents(prev =>
      prev.map(e =>
        e.id === eventId
          ? { ...e, ticketsSold: e.ticketsSold + quantity }
          : e
      )
    );
    logActivity('TICKET_BOOKED', {
      eventName: event.title,
      quantity,
      price: newBooking.totalPrice,
    });
    return newBooking;
  };

  const cancelBooking = (bookingId) => {
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) return false;

    const event = events.find(e => e.id === booking.eventId);
    setBookings(prev => prev.filter(b => b.id !== bookingId));
    setEvents(prev =>
      prev.map(e =>
        e.id === booking.eventId
          ? { ...e, ticketsSold: Math.max(0, e.ticketsSold - booking.quantity) }
          : e
      )
    );
    logActivity('BOOKING_CANCELLED', {
      eventName: event?.title,
      quantity: booking.quantity,
    });
    return true;
  };

  const value = {
    user,
    events,
    bookings,
    activities,
    users,
    currentPage,
    setCurrentPage,
    isAdmin,
    register,
    login,
    logout,
    createEvent,
    bookTicket,
    cancelBooking,
    logActivity,
    setLoading,
    loading,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

// ============================================================================
// UI COMPONENTS
// ============================================================================

const Header = () => {
  const { user, logout, currentPage, setCurrentPage, isAdmin } = useAppContext();

  return (
    <header style={styles.header}>
      <div style={styles.headerContent}>
        <div
          style={styles.logo}
          onClick={() => setCurrentPage('home')}
          role="button"
          tabIndex="0"
        >
          <span style={styles.logoIcon}>🎟</span>
          <span style={styles.logoText}>EventHub</span>
        </div>

        <nav style={styles.nav}>
          {user ? (
            <>
              <button
                style={{
                  ...styles.navButton,
                  ...(currentPage === 'events' && styles.navButtonActive),
                }}
                onClick={() => setCurrentPage('events')}
              >
                Events
              </button>
              {isAdmin ? (
                <button
                  style={{
                    ...styles.navButton,
                    ...(currentPage === 'admin' && styles.navButtonActive),
                  }}
                  onClick={() => setCurrentPage('admin')}
                >
                  Admin
                </button>
              ) : (
                <button
                  style={{
                    ...styles.navButton,
                    ...(currentPage === 'dashboard' && styles.navButtonActive),
                  }}
                  onClick={() => setCurrentPage('dashboard')}
                >
                  My Bookings
                </button>
              )}
              <div style={styles.userSection}>
                <span style={styles.userName}>{user.name}</span>
                <button style={styles.logoutBtn} onClick={logout}>
                  Logout
                </button>
              </div>
            </>
          ) : (
            <>
              <button
                style={{
                  ...styles.navButton,
                  ...(currentPage === 'login' && styles.navButtonActive),
                }}
                onClick={() => setCurrentPage('login')}
              >
                Login
              </button>
              <button
                style={{
                  ...styles.navButton,
                  ...(currentPage === 'register' && styles.navButtonActive),
                }}
                onClick={() => setCurrentPage('register')}
              >
                Register
              </button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
};

const HomePage = () => {
  const { setCurrentPage } = useAppContext();

  return (
    <div style={styles.hero}>
      <div style={styles.heroContent}>
        <h1 style={styles.heroTitle}>
          Discover Your Next Experience
        </h1>
        <p style={styles.heroSubtitle}>
          Book tickets to the most exciting events, instantly and securely
        </p>
        <button
          style={styles.heroButton}
          onClick={() => setCurrentPage('events')}
        >
          Browse Events
        </button>
      </div>
    </div>
  );
};

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login, setCurrentPage } = useAppContext();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (login(email, password)) {
      setCurrentPage('events');
    } else {
      setError('Invalid email or password');
    }
  };

  return (
    <div style={styles.authContainer}>
      <form style={styles.authForm} onSubmit={handleSubmit}>
        <h2 style={styles.formTitle}>Sign In</h2>
        {error && <div style={styles.errorMessage}>{error}</div>}

        <div style={styles.formGroup}>
          <label style={styles.label}>Email</label>
          <input
            type="email"
            style={styles.input}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Password</label>
          <input
            type="password"
            style={styles.input}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            required
          />
        </div>

        <button type="submit" style={styles.submitButton}>
          Sign In
        </button>

        <p style={styles.formFooter}>
          No account? Try demo: admin@events.com / password
        </p>
      </form>
    </div>
  );
};

const RegisterForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { register, setCurrentPage } = useAppContext();

  const handleSubmit = (e) => {
    e.preventDefault();
    register(email, password, name);
    setCurrentPage('events');
  };

  return (
    <div style={styles.authContainer}>
      <form style={styles.authForm} onSubmit={handleSubmit}>
        <h2 style={styles.formTitle}>Create Account</h2>

        <div style={styles.formGroup}>
          <label style={styles.label}>Name</label>
          <input
            type="text"
            style={styles.input}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your name"
            required
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Email</label>
          <input
            type="email"
            style={styles.input}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Password</label>
          <input
            type="password"
            style={styles.input}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            required
          />
        </div>

        <button type="submit" style={styles.submitButton}>
          Create Account
        </button>
      </form>
    </div>
  );
};

const EventsBrowse = () => {
  const { events, user, setCurrentPage } = useAppContext();
  const [selectedEvent, setSelectedEvent] = useState(null);

  if (selectedEvent) {
    return (
      <EventDetailView
        event={selectedEvent}
        onBack={() => setSelectedEvent(null)}
      />
    );
  }

  return (
    <div style={styles.eventsContainer}>
      <div style={styles.eventsHeader}>
        <h1 style={styles.sectionTitle}>Upcoming Events</h1>
      </div>

      {events.length === 0 ? (
        <div style={styles.emptyState}>
          <p>No events available yet. Check back soon!</p>
        </div>
      ) : (
        <div style={styles.eventGrid}>
          {events.map(event => (
            <div key={event.id} style={styles.eventCard}>
              <div style={styles.eventCardHeader}>
                <h3 style={styles.eventTitle}>{event.title}</h3>
                <span style={styles.eventCategory}>{event.category}</span>
              </div>

              <p style={styles.eventDescription}>{event.description}</p>

              <div style={styles.eventDetails}>
                <div style={styles.eventDetail}>
                  <span style={styles.detailLabel}>📅</span>
                  <span>{event.date}</span>
                </div>
                <div style={styles.eventDetail}>
                  <span style={styles.detailLabel}>📍</span>
                  <span>{event.location}</span>
                </div>
                <div style={styles.eventDetail}>
                  <span style={styles.detailLabel}>💰</span>
                  <span>${event.price}</span>
                </div>
              </div>

              <div style={styles.ticketAvailability}>
                <div style={styles.availabilityBar}>
                  <div
                    style={{
                      ...styles.availabilityFill,
                      width: `${(event.ticketsSold / event.capacity) * 100}%`,
                    }}
                  />
                </div>
                <span style={styles.availabilityText}>
                  {event.capacity - event.ticketsSold} of {event.capacity} left
                </span>
              </div>

              <button
                style={styles.eventCardButton}
                onClick={() => setSelectedEvent(event)}
              >
                View & Book →
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const EventDetailView = ({ event, onBack }) => {
  const [quantity, setQuantity] = useState(1);
  const { bookTicket, user, setCurrentPage } = useAppContext();

  const handleBook = () => {
    if (!user) {
      setCurrentPage('login');
      return;
    }
    const booking = bookTicket(event.id, quantity);
    if (booking) {
      setCurrentPage('dashboard');
    }
  };

  return (
    <div style={styles.eventDetailContainer}>
      <button style={styles.backButton} onClick={onBack}>
        ← Back to Events
      </button>

      <div style={styles.eventDetailContent}>
        <div style={styles.eventDetailMain}>
          <div style={styles.eventDetailHeader}>
            <span style={styles.eventCategory}>{event.category}</span>
            <h1 style={styles.eventDetailTitle}>{event.title}</h1>
          </div>

          <div style={styles.eventDetailMeta}>
            <div style={styles.metaRow}>
              <span style={styles.metaLabel}>Date & Time</span>
              <span style={styles.metaValue}>{event.date}</span>
            </div>
            <div style={styles.metaRow}>
              <span style={styles.metaLabel}>Location</span>
              <span style={styles.metaValue}>{event.location}</span>
            </div>
            <div style={styles.metaRow}>
              <span style={styles.metaLabel}>Organizer</span>
              <span style={styles.metaValue}>{event.organizer}</span>
            </div>
          </div>

          <div style={styles.eventDetailDescription}>
            <h2 style={styles.sectionSubtitle}>About This Event</h2>
            <p>{event.description}</p>
          </div>

          <div style={styles.ticketAvailabilityDetail}>
            <h3 style={styles.sectionSubtitle}>Availability</h3>
            <div style={styles.availabilityBar}>
              <div
                style={{
                  ...styles.availabilityFill,
                  width: `${(event.ticketsSold / event.capacity) * 100}%`,
                }}
              />
            </div>
            <p style={styles.availabilityDetailText}>
              {event.capacity - event.ticketsSold} tickets available out of {event.capacity}
            </p>
          </div>
        </div>

        <div style={styles.bookingPanel}>
          <div style={styles.bookingPanelContent}>
            <h2 style={styles.priceDisplay}>${event.price}</h2>
            <p style={styles.priceLabel}>per ticket</p>

            <div style={styles.quantitySelector}>
              <label style={styles.quantityLabel}>Quantity</label>
              <div style={styles.quantityControls}>
                <button
                  style={styles.quantityBtn}
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                >
                  −
                </button>
                <span style={styles.quantityDisplay}>{quantity}</span>
                <button
                  style={styles.quantityBtn}
                  onClick={() =>
                    setQuantity(
                      Math.min(
                        event.capacity - event.ticketsSold,
                        quantity + 1
                      )
                    )
                  }
                >
                  +
                </button>
              </div>
            </div>

            <div style={styles.totalCalculation}>
              <span style={styles.totalLabel}>Total</span>
              <span style={styles.totalPrice}>${(event.price * quantity).toFixed(2)}</span>
            </div>

            <button
              style={styles.bookingButton}
              onClick={handleBook}
              disabled={event.ticketsSold >= event.capacity}
            >
              {event.ticketsSold >= event.capacity
                ? 'Event Full'
                : 'Book Tickets →'}
            </button>

            {!user && (
              <p style={styles.loginPrompt}>Sign in to complete your booking</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const UserDashboard = () => {
  const { user, bookings, cancelBooking } = useAppContext();
  const userBookings = bookings.filter(b => b.userId === user?.id);

  if (userBookings.length === 0) {
    return (
      <div style={styles.dashboardContainer}>
        <h1 style={styles.sectionTitle}>My Bookings</h1>
        <div style={styles.emptyState}>
          <p>You haven't booked any tickets yet.</p>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.dashboardContainer}>
      <h1 style={styles.sectionTitle}>My Bookings</h1>

      <div style={styles.bookingsList}>
        {userBookings.map(booking => {
          const events = require('./event-management-app.js');
          return (
            <div key={booking.id} style={styles.bookingCard}>
              <div style={styles.bookingCardHeader}>
                <h2 style={styles.bookingTitle}>Booking #{booking.id.slice(0, 8)}</h2>
                <span style={styles.bookingDate}>{booking.bookingDate}</span>
              </div>

              <div style={styles.bookingDetails}>
                <div style={styles.bookingDetail}>
                  <span>Tickets:</span>
                  <strong>{booking.quantity}x</strong>
                </div>
                <div style={styles.bookingDetail}>
                  <span>Total:</span>
                  <strong>${booking.totalPrice.toFixed(2)}</strong>
                </div>
              </div>

              <div style={styles.ticketsSection}>
                <h3 style={styles.ticketsTitle}>Your Tickets</h3>
                <div style={styles.ticketsList}>
                  {booking.tickets.map((ticket, idx) => (
                    <div key={idx} style={styles.ticketItem}>
                      <div style={styles.qrPlaceholder}>📱 QR</div>
                      <div>
                        <div style={styles.ticketNumber}>Ticket {idx + 1}</div>
                        <div style={styles.ticketCode}>{ticket.qrCode}</div>
                        <div style={styles.ticketStatus}>{ticket.status}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <button
                style={styles.cancelButton}
                onClick={() => cancelBooking(booking.id)}
              >
                Cancel Booking
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const AdminDashboard = () => {
  const { events, bookings, activities, users, setCurrentPage } = useAppContext();
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    location: '',
    organizer: '',
    price: '',
    capacity: '',
    category: '',
  });

  const handleCreateEvent = (e) => {
    e.preventDefault();
    const { createEvent } = useAppContext();
    createEvent({
      ...formData,
      price: parseFloat(formData.price),
      capacity: parseInt(formData.capacity),
    });
    setFormData({
      title: '',
      description: '',
      date: '',
      location: '',
      organizer: '',
      price: '',
      capacity: '',
      category: '',
    });
    setShowCreateEvent(false);
  };

  const totalRevenue = bookings.reduce((sum, b) => sum + b.totalPrice, 0);
  const totalBookings = bookings.length;
  const totalEvents = events.length;

  return (
    <div style={styles.adminContainer}>
      <h1 style={styles.sectionTitle}>Admin Dashboard</h1>

      <div style={styles.adminStats}>
        <div style={styles.statCard}>
          <div style={styles.statNumber}>{totalEvents}</div>
          <div style={styles.statLabel}>Events</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statNumber}>{totalBookings}</div>
          <div style={styles.statLabel}>Bookings</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statNumber}>${totalRevenue.toFixed(0)}</div>
          <div style={styles.statLabel}>Revenue</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statNumber}>{users.length}</div>
          <div style={styles.statLabel}>Users</div>
        </div>
      </div>

      <div style={styles.adminSection}>
        <div style={styles.sectionHeader}>
          <h2 style={styles.sectionSubtitle}>Events Management</h2>
          <button
            style={styles.createEventBtn}
            onClick={() => setShowCreateEvent(!showCreateEvent)}
          >
            {showCreateEvent ? 'Cancel' : '+ New Event'}
          </button>
        </div>

        {showCreateEvent && (
          <form style={styles.eventForm} onSubmit={handleCreateEvent}>
            <div style={styles.formRow}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Event Title</label>
                <input
                  type="text"
                  style={styles.input}
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  required
                />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Category</label>
                <input
                  type="text"
                  style={styles.input}
                  value={formData.category}
                  onChange={(e) =>
                    setFormData({ ...formData, category: e.target.value })
                  }
                  required
                />
              </div>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Description</label>
              <textarea
                style={{...styles.input, minHeight: '100px'}}
                value={formData.description}
                onChange={(e) =>
                  setFormData({ ...formData, description: e.target.value })
                }
                required
              />
            </div>

            <div style={styles.formRow}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Date</label>
                <input
                  type="datetime-local"
                  style={styles.input}
                  value={formData.date}
                  onChange={(e) =>
                    setFormData({ ...formData, date: e.target.value })
                  }
                  required
                />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Location</label>
                <input
                  type="text"
                  style={styles.input}
                  value={formData.location}
                  onChange={(e) =>
                    setFormData({ ...formData, location: e.target.value })
                  }
                  required
                />
              </div>
            </div>

            <div style={styles.formRow}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Organizer</label>
                <input
                  type="text"
                  style={styles.input}
                  value={formData.organizer}
                  onChange={(e) =>
                    setFormData({ ...formData, organizer: e.target.value })
                  }
                  required
                />
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Price per Ticket</label>
                <input
                  type="number"
                  style={styles.input}
                  value={formData.price}
                  onChange={(e) =>
                    setFormData({ ...formData, price: e.target.value })
                  }
                  step="0.01"
                  required
                />
              </div>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Capacity</label>
              <input
                type="number"
                style={styles.input}
                value={formData.capacity}
                onChange={(e) =>
                  setFormData({ ...formData, capacity: e.target.value })
                }
                required
              />
            </div>

            <button type="submit" style={styles.submitButton}>
              Create Event
            </button>
          </form>
        )}

        <div style={styles.eventsList}>
          {events.map(event => (
            <div key={event.id} style={styles.adminEventCard}>
              <div>
                <h3 style={styles.eventTitle}>{event.title}</h3>
                <p style={styles.eventMeta}>
                  {event.date} • {event.location} • ${event.price}
                </p>
                <p style={styles.eventStats}>
                  {event.ticketsSold}/{event.capacity} tickets sold
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={styles.adminSection}>
        <h2 style={styles.sectionSubtitle}>Activity Log</h2>
        <div style={styles.activityLog}>
          {activities.slice(0, 10).map(activity => (
            <div key={activity.id} style={styles.activityItem}>
              <span style={styles.activityTime}>{activity.timestamp}</span>
              <span style={styles.activityAction}>{activity.action}</span>
              <span style={styles.activityDetails}>
                {JSON.stringify(activity.details).substring(0, 50)}...
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// MAIN APP
// ============================================================================

const App = () => {
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    // Initialize with sample data
    if (!initialized) {
      const sampleEvents = [
        {
          id: '1',
          title: 'Tech Conference 2024',
          description: 'Annual tech conference featuring keynotes from industry leaders',
          date: '2024-08-15',
          location: 'Convention Center, NYC',
          organizer: 'TechEvents Inc',
          price: 99.99,
          capacity: 500,
          category: 'Conference',
          ticketsSold: 245,
          createdAt: new Date().toLocaleString(),
          createdBy: 'admin',
        },
        {
          id: '2',
          title: 'Summer Music Festival',
          description: 'Three days of live music performances',
          date: '2024-07-20',
          location: 'Central Park, NYC',
          organizer: 'Music Productions',
          price: 149.99,
          capacity: 3000,
          category: 'Music',
          ticketsSold: 1200,
          createdAt: new Date().toLocaleString(),
          createdBy: 'admin',
        },
        {
          id: '3',
          title: 'Web Development Workshop',
          description: 'Learn modern web development practices',
          date: '2024-09-01',
          location: 'Tech Hub, San Francisco',
          organizer: 'Dev Academy',
          price: 79.99,
          capacity: 100,
          category: 'Workshop',
          ticketsSold: 45,
          createdAt: new Date().toLocaleString(),
          createdBy: 'admin',
        },
      ];

      // Initialize app state
      const initialState = {
        user: null,
        events: sampleEvents,
        bookings: [],
        activities: [],
        users: [
          {
            id: 'admin-001',
            email: 'admin@events.com',
            password: 'password',
            name: 'Admin User',
            createdAt: new Date().toLocaleString(),
          },
        ],
      };

      setInitialized(true);
    }
  }, [initialized]);

  const { currentPage, user, isAdmin } = useAppContext();

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'login':
        return <LoginForm />;
      case 'register':
        return <RegisterForm />;
      case 'events':
        return <EventsBrowse />;
      case 'dashboard':
        return user ? <UserDashboard /> : <LoginForm />;
      case 'admin':
        return isAdmin ? <AdminDashboard /> : <HomePage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div style={styles.appContainer}>
      <Header />
      <main style={styles.main}>
        {renderPage()}
      </main>
      <Footer />
    </div>
  );
};

const Footer = () => (
  <footer style={styles.footer}>
    <p style={styles.footerText}>© 2024 EventHub. All rights reserved.</p>
  </footer>
);

// ============================================================================
// STYLES (MODERN TICKET BOOTH AESTHETIC)
// ============================================================================

const styles = {
  appContainer: {
    fontFamily: '"Segoe UI", Tahoma, Geneva, Verdana, sans-serif',
    backgroundColor: '#fafafa',
    color: '#1a1a1a',
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
  },
  header: {
    backgroundColor: '#ffffff',
    borderBottom: '1px solid #e0e0e0',
    boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
    position: 'sticky',
    top: 0,
    zIndex: 100,
  },
  headerContent: {
    maxWidth: '1200px',
    margin: '0 auto',
    padding: '0 20px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: '64px',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    cursor: 'pointer',
    fontSize: '18px',
    fontWeight: '700',
    letterSpacing: '-0.5px',
  },
  logoIcon: {
    fontSize: '28px',
  },
  logoText: {
    color: '#0a7ea4',
  },
  nav: {
    display: 'flex',
    alignItems: 'center',
    gap: '24px',
  },
  navButton: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    color: '#666',
    padding: '8px 0',
    transition: 'color 0.2s',
  },
  navButtonActive: {
    color: '#0a7ea4',
    borderBottom: '2px solid #f4a261',
  },
  userSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    marginLeft: '12px',
    paddingLeft: '12px',
    borderLeft: '1px solid #e0e0e0',
  },
  userName: {
    fontSize: '13px',
    color: '#666',
  },
  logoutBtn: {
    background: '#f4a261',
    border: 'none',
    color: '#fff',
    padding: '6px 14px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '13px',
    fontWeight: '600',
    transition: 'background 0.2s',
  },
  main: {
    flex: 1,
    maxWidth: '1200px',
    margin: '0 auto',
    width: '100%',
    padding: '40px 20px',
  },
  hero: {
    textAlign: 'center',
    paddingBottom: '80px',
  },
  heroContent: {
    marginBottom: '40px',
  },
  heroTitle: {
    fontSize: '48px',
    fontWeight: '700',
    lineHeight: '1.2',
    marginBottom: '16px',
    color: '#0a3d62',
  },
  heroSubtitle: {
    fontSize: '18px',
    color: '#666',
    marginBottom: '32px',
    lineHeight: '1.6',
  },
  heroButton: {
    background: '#0a7ea4',
    color: '#fff',
    border: 'none',
    padding: '14px 36px',
    fontSize: '16px',
    fontWeight: '600',
    borderRadius: '6px',
    cursor: 'pointer',
    transition: 'all 0.3s',
    boxShadow: '0 4px 12px rgba(10, 126, 164, 0.2)',
  },
  authContainer: {
    display: 'flex',
    justifyContent: 'center',
    minHeight: '500px',
    alignItems: 'center',
  },
  authForm: {
    width: '100%',
    maxWidth: '400px',
    backgroundColor: '#fff',
    padding: '40px',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
  },
  formTitle: {
    fontSize: '24px',
    fontWeight: '700',
    marginBottom: '24px',
    color: '#0a3d62',
  },
  formGroup: {
    marginBottom: '20px',
  },
  label: {
    display: 'block',
    fontSize: '13px',
    fontWeight: '600',
    marginBottom: '6px',
    color: '#333',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
  input: {
    width: '100%',
    padding: '10px 12px',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '14px',
    fontFamily: 'inherit',
    boxSizing: 'border-box',
    transition: 'border-color 0.2s',
  },
  submitButton: {
    width: '100%',
    padding: '12px',
    backgroundColor: '#0a7ea4',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    fontSize: '15px',
    fontWeight: '600',
    cursor: 'pointer',
    marginTop: '20px',
  },
  errorMessage: {
    background: '#fee',
    color: '#c33',
    padding: '12px',
    borderRadius: '4px',
    marginBottom: '20px',
    fontSize: '13px',
  },
  formFooter: {
    fontSize: '12px',
    color: '#999',
    marginTop: '16px',
    textAlign: 'center',
  },
  eventsContainer: {
    width: '100%',
  },
  eventsHeader: {
    marginBottom: '40px',
  },
  sectionTitle: {
    fontSize: '32px',
    fontWeight: '700',
    color: '#0a3d62',
    marginBottom: '8px',
  },
  sectionSubtitle: {
    fontSize: '18px',
    fontWeight: '600',
    color: '#0a3d62',
    marginBottom: '16px',
  },
  eventGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
    gap: '24px',
  },
  eventCard: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    padding: '24px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
    transition: 'all 0.3s',
    display: 'flex',
    flexDirection: 'column',
  },
  eventCardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '12px',
  },
  eventTitle: {
    fontSize: '18px',
    fontWeight: '700',
    color: '#0a3d62',
    margin: 0,
  },
  eventCategory: {
    background: '#e8f4f8',
    color: '#0a7ea4',
    padding: '4px 10px',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: '600',
    whiteSpace: 'nowrap',
  },
  eventDescription: {
    fontSize: '13px',
    color: '#666',
    lineHeight: '1.5',
    marginBottom: '16px',
  },
  eventDetails: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
    marginBottom: '16px',
    paddingBottom: '16px',
    borderBottom: '1px solid #eee',
  },
  eventDetail: {
    fontSize: '13px',
    display: 'flex',
    gap: '8px',
    color: '#666',
  },
  detailLabel: {
    width: '20px',
  },
  ticketAvailability: {
    marginBottom: '16px',
  },
  availabilityBar: {
    width: '100%',
    height: '6px',
    backgroundColor: '#eee',
    borderRadius: '3px',
    overflow: 'hidden',
    marginBottom: '6px',
  },
  availabilityFill: {
    height: '100%',
    backgroundColor: '#f4a261',
    transition: 'width 0.3s',
  },
  availabilityText: {
    fontSize: '12px',
    color: '#999',
  },
  eventCardButton: {
    marginTop: 'auto',
    background: '#0a7ea4',
    color: '#fff',
    border: 'none',
    padding: '12px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '600',
  },
  eventDetailContainer: {
    maxWidth: '900px',
    margin: '0 auto',
  },
  backButton: {
    background: 'none',
    border: 'none',
    color: '#0a7ea4',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '600',
    marginBottom: '24px',
    padding: 0,
  },
  eventDetailContent: {
    display: 'grid',
    gridTemplateColumns: '1fr 380px',
    gap: '32px',
  },
  eventDetailMain: {
    backgroundColor: '#fff',
    padding: '32px',
    borderRadius: '8px',
  },
  eventDetailHeader: {
    marginBottom: '24px',
  },
  eventDetailTitle: {
    fontSize: '36px',
    fontWeight: '700',
    color: '#0a3d62',
    margin: '12px 0 0 0',
  },
  eventDetailMeta: {
    display: 'flex',
    flexDirection: 'column',
    gap: '16px',
    marginBottom: '24px',
    paddingBottom: '24px',
    borderBottom: '1px solid #eee',
  },
  metaRow: {
    display: 'grid',
    gridTemplateColumns: '120px 1fr',
    gap: '16px',
  },
  metaLabel: {
    fontSize: '13px',
    fontWeight: '600',
    color: '#999',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
  metaValue: {
    fontSize: '15px',
    color: '#333',
  },
  eventDetailDescription: {
    marginBottom: '24px',
  },
  eventDetailDescription: {
    marginBottom: '24px',
  },
  ticketAvailabilityDetail: {
    background: '#f5f5f5',
    padding: '20px',
    borderRadius: '6px',
  },
  availabilityDetailText: {
    fontSize: '13px',
    color: '#666',
    marginTop: '8px',
  },
  bookingPanel: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
    height: 'fit-content',
    position: 'sticky',
    top: '100px',
  },
  bookingPanelContent: {
    padding: '24px',
  },
  priceDisplay: {
    fontSize: '36px',
    fontWeight: '700',
    color: '#f4a261',
    margin: '0 0 4px 0',
  },
  priceLabel: {
    fontSize: '12px',
    color: '#999',
    margin: '0 0 24px 0',
  },
  quantitySelector: {
    marginBottom: '24px',
  },
  quantityLabel: {
    fontSize: '13px',
    fontWeight: '600',
    display: 'block',
    marginBottom: '8px',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    color: '#666',
  },
  quantityControls: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    background: '#f5f5f5',
    borderRadius: '4px',
    padding: '6px',
    width: 'fit-content',
  },
  quantityBtn: {
    background: 'none',
    border: 'none',
    fontSize: '16px',
    cursor: 'pointer',
    color: '#0a7ea4',
    fontWeight: '600',
    width: '28px',
    height: '28px',
    borderRadius: '3px',
  },
  quantityDisplay: {
    minWidth: '32px',
    textAlign: 'center',
    fontSize: '15px',
    fontWeight: '600',
  },
  totalCalculation: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'baseline',
    padding: '16px 0',
    marginBottom: '20px',
    borderTop: '1px solid #eee',
    borderBottom: '1px solid #eee',
  },
  totalLabel: {
    fontSize: '13px',
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    color: '#666',
  },
  totalPrice: {
    fontSize: '20px',
    fontWeight: '700',
    color: '#0a3d62',
  },
  bookingButton: {
    width: '100%',
    padding: '14px',
    backgroundColor: '#0a7ea4',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    fontSize: '15px',
    fontWeight: '600',
    cursor: 'pointer',
    marginBottom: '12px',
  },
  loginPrompt: {
    fontSize: '12px',
    color: '#999',
    textAlign: 'center',
    margin: 0,
  },
  dashboardContainer: {
    width: '100%',
  },
  emptyState: {
    textAlign: 'center',
    padding: '60px 20px',
    backgroundColor: '#fff',
    borderRadius: '8px',
    color: '#999',
  },
  bookingsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
  },
  bookingCard: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    padding: '24px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
  },
  bookingCardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '16px',
    paddingBottom: '16px',
    borderBottom: '1px solid #eee',
  },
  bookingTitle: {
    fontSize: '18px',
    fontWeight: '700',
    color: '#0a3d62',
    margin: 0,
  },
  bookingDate: {
    fontSize: '13px',
    color: '#999',
  },
  bookingDetails: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: '20px',
    marginBottom: '24px',
    padding: '16px 0',
    borderBottom: '1px solid #eee',
  },
  bookingDetail: {
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
  },
  ticketsSection: {
    marginBottom: '20px',
  },
  ticketsTitle: {
    fontSize: '14px',
    fontWeight: '600',
    color: '#0a3d62',
    marginBottom: '12px',
  },
  ticketsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
  },
  ticketItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
    background: '#f9f9f9',
    padding: '12px',
    borderRadius: '4px',
    border: '1px solid #eee',
  },
  qrPlaceholder: {
    width: '60px',
    height: '60px',
    background: '#e8f4f8',
    borderRadius: '4px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#0a7ea4',
    fontWeight: '600',
    fontSize: '12px',
  },
  ticketNumber: {
    fontSize: '13px',
    fontWeight: '600',
    color: '#0a3d62',
  },
  ticketCode: {
    fontSize: '12px',
    color: '#666',
    fontFamily: 'monospace',
  },
  ticketStatus: {
    fontSize: '11px',
    color: '#4caf50',
    fontWeight: '600',
  },
  cancelButton: {
    background: '#fee',
    color: '#c33',
    border: '1px solid #fcc',
    padding: '10px 16px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '13px',
    fontWeight: '600',
  },
  adminContainer: {
    width: '100%',
  },
  adminStats: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '20px',
    marginBottom: '40px',
  },
  statCard: {
    backgroundColor: '#fff',
    padding: '24px',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
    textAlign: 'center',
  },
  statNumber: {
    fontSize: '32px',
    fontWeight: '700',
    color: '#0a7ea4',
  },
  statLabel: {
    fontSize: '13px',
    color: '#999',
    marginTop: '4px',
  },
  adminSection: {
    backgroundColor: '#fff',
    borderRadius: '8px',
    padding: '24px',
    marginBottom: '24px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
  },
  sectionHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
  },
  createEventBtn: {
    background: '#f4a261',
    color: '#fff',
    border: 'none',
    padding: '10px 16px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '13px',
    fontWeight: '600',
  },
  eventForm: {
    background: '#f9f9f9',
    padding: '20px',
    borderRadius: '6px',
    marginBottom: '20px',
  },
  formRow: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: '16px',
  },
  eventsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '12px',
  },
  adminEventCard: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '16px',
    background: '#f9f9f9',
    borderRadius: '4px',
    borderLeft: '4px solid #f4a261',
  },
  eventMeta: {
    fontSize: '13px',
    color: '#999',
    margin: '4px 0',
  },
  eventStats: {
    fontSize: '12px',
    color: '#0a7ea4',
    fontWeight: '600',
  },
  activityLog: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    maxHeight: '400px',
    overflowY: 'auto',
  },
  activityItem: {
    display: 'grid',
    gridTemplateColumns: '140px 150px 1fr',
    gap: '16px',
    padding: '12px',
    background: '#f9f9f9',
    borderRadius: '4px',
    fontSize: '12px',
  },
  activityTime: {
    color: '#999',
    fontFamily: 'monospace',
  },
  activityAction: {
    fontWeight: '600',
    color: '#0a7ea4',
  },
  activityDetails: {
    color: '#666',
  },
  footer: {
    borderTop: '1px solid #e0e0e0',
    padding: '24px 20px',
    textAlign: 'center',
    backgroundColor: '#fff',
    marginTop: 'auto',
  },
  footerText: {
    fontSize: '13px',
    color: '#999',
    margin: 0,
  },
};

// ============================================================================
// RENDER APP
// ============================================================================

function EventManagementApp() {
  return (
    <AppProvider>
      <App />
    </AppProvider>
  );
}

export default EventManagementApp;
