# EventHub: Complete Event Management Platform

A production-ready, full-stack event management system with QR code ticketing, real-time dashboards, and comprehensive activity logging. Built with React, Express, and SQLite.

## 🎯 Features

### For Customers
- **Event Discovery** - Browse upcoming events with real-time availability
- **Ticket Booking** - Secure one-click booking with quantity selection
- **QR Code Tickets** - Digital tickets with unique QR codes for entry
- **User Dashboard** - View all bookings, tickets, and booking history
- **Booking Management** - Cancel bookings and retrieve tickets anytime

### For Administrators
- **Event Management** - Create, edit, and delete events with full details
- **Admin Dashboard** - Real-time stats on events, bookings, and revenue
- **Ticket Scanning** - Scan QR codes at the door to verify entry
- **Activity Logging** - Complete audit trail of all system actions
- **Analytics** - Track per-event performance and sales metrics

### Technical Features
- **User Authentication** - Secure JWT-based authentication
- **Database Persistence** - SQLite with normalized schema
- **QR Code Generation** - Automatic QR code creation for each ticket
- **Activity Tracking** - Comprehensive logging of all user actions
- **Admin Verification** - Role-based access control
- **Error Handling** - Graceful error responses with helpful messages

## 🏗️ System Architecture

```
EventHub/
├── Frontend (React)
│   ├── Authentication (Login/Register)
│   ├── Event Browsing & Discovery
│   ├── Ticket Booking Flow
│   ├── User Dashboard (Bookings & Tickets)
│   └── Admin Dashboard (Events, Analytics, Activity Log)
│
├── Backend (Express.js)
│   ├── REST API Endpoints
│   ├── JWT Authentication
│   ├── QR Code Generation
│   └── Database Operations
│
└── Database (SQLite)
    ├── Users Table (email, password, role)
    ├── Events Table (event details & capacity)
    ├── Bookings Table (transaction records)
    ├── Tickets Table (individual tickets with QR codes)
    └── Activities Table (audit log)
```

### Database Schema

**users**
```sql
- id (TEXT, PRIMARY KEY)
- email (TEXT, UNIQUE)
- password (TEXT)
- name (TEXT)
- is_admin (BOOLEAN)
- created_at (TIMESTAMP)
```

**events**
```sql
- id (TEXT, PRIMARY KEY)
- title, description, date, location, organizer
- price (REAL), capacity (INTEGER)
- tickets_sold (INTEGER) - auto-tracked
- category (TEXT)
- created_by (FOREIGN KEY to users)
- created_at (TIMESTAMP)
```

**bookings**
```sql
- id (TEXT, PRIMARY KEY)
- event_id (FOREIGN KEY)
- user_id (FOREIGN KEY)
- quantity (INTEGER)
- total_price (REAL)
- status ('active', 'cancelled')
- booking_date (TIMESTAMP)
```

**tickets**
```sql
- id (TEXT, PRIMARY KEY)
- booking_id (FOREIGN KEY)
- qr_code (TEXT, UNIQUE) - Format: TICKET-{bookingId}-{ticketNumber}
- status ('valid', 'used')
- scanned_at (TIMESTAMP, nullable)
- created_at (TIMESTAMP)
```

**activities**
```sql
- id (TEXT, PRIMARY KEY)
- user_id (TEXT, nullable)
- action (TEXT) - e.g., 'USER_LOGIN', 'TICKET_BOOKED', 'EVENT_CREATED'
- details (JSON) - Additional context
- timestamp (TIMESTAMP)
```

## 🚀 Getting Started

### Prerequisites
- Node.js 16+
- npm or yarn

### Installation

```bash
# Clone or download the project
cd event-management-platform

# Install dependencies
npm install

# Start the server
npm start
```

The server runs on `http://localhost:5000`

### React Frontend Setup

For development with React, use your preferred bundler:

```bash
# Option 1: Create React App
npx create-react-app frontend
cd frontend
npm install react-router-dom

# Copy the React component from event-management-app.js into src/App.js

# Option 2: Vite (faster)
npm create vite@latest frontend -- --template react
cd frontend
npm install react-router-dom

# Run development server
npm run dev
```

### Demo Credentials

```
Email: admin@events.com
Password: password
```

This account has admin privileges and can create/manage events and view activity logs.

## 📡 API Endpoints

### Authentication
- `POST /api/auth/register` - Create new account
- `POST /api/auth/login` - Sign in and get JWT token

### Events
- `GET /api/events` - List all events
- `GET /api/events/:id` - Get event details
- `POST /api/events` - Create event (admin only)
- `PUT /api/events/:id` - Update event (admin only)
- `DELETE /api/events/:id` - Delete event (admin only)

### Bookings
- `POST /api/bookings` - Book tickets
- `GET /api/bookings` - Get user's bookings
- `GET /api/bookings/:id` - Get booking details
- `DELETE /api/bookings/:id` - Cancel booking

### Tickets & QR Codes
- `GET /api/tickets/:ticketId/qr` - Get QR code for ticket
- `POST /api/tickets/:ticketId/scan` - Mark ticket as used (admin)

### Admin & Analytics
- `GET /api/admin/stats` - Dashboard stats
- `GET /api/admin/events/:id/stats` - Event-specific analytics
- `GET /api/activities` - Activity log

## 🎨 Design System

The frontend uses a **modern ticket booth aesthetic** with:

- **Primary Color**: Teal (`#0a7ea4`) - Professional, tech-forward
- **Accent Color**: Warm Amber (`#f4a261`) - Calls to action
- **Background**: Light gray (`#fafafa`) - Clean, minimal
- **Typography**: 
  - Display: Segoe UI (bold, clear)
  - Body: Segoe UI (readable, accessible)

### Visual Elements
- Card-based layout for events
- Progress bars for ticket availability
- Perforated/ticket-stub style for bookings
- QR code placeholder in ticket cards
- Activity log with timestamps

## 📊 User Flows

### Customer Journey
1. **Browse** → Visit home, view upcoming events
2. **Select** → Click event to see full details and availability
3. **Book** → Choose quantity, review total price
4. **Checkout** → Create account or login
5. **Receive** → Get QR code tickets via dashboard
6. **Attend** → Show QR code at venue

### Admin Journey
1. **Create Event** → Fill form with event details and capacity
2. **Monitor** → Watch real-time bookings and revenue
3. **Manage** → Update event info or cancel if needed
4. **Verify Entry** → Scan QR codes at venue
5. **Analytics** → Review activity log and performance metrics

## 🔐 Security Features

- **JWT Authentication** - Stateless auth with 24h expiration
- **Password Storage** - In production, use bcrypt (demo uses plain for simplicity)
- **Role-Based Access** - Admin endpoints verify `is_admin` flag
- **CORS Protection** - Whitelist trusted origins
- **Input Validation** - Check required fields before processing
- **Audit Trail** - Every action logged with timestamp and user ID

### Production Security Checklist
- [ ] Replace JWT_SECRET with strong key
- [ ] Use bcrypt for password hashing
- [ ] Enable HTTPS/TLS
- [ ] Add rate limiting middleware
- [ ] Implement CORS with specific domains
- [ ] Add request logging/monitoring
- [ ] Use environment variables for secrets
- [ ] Regular database backups
- [ ] SQL injection prevention (using parameterized queries ✓)

## 📈 Scaling Considerations

### Current Implementation
- SQLite database (file-based, single-threaded)
- In-memory activity log (limited to 100 entries)
- Synchronous API responses

### Production Upgrades
- **Database**: PostgreSQL for concurrent access
- **Caching**: Redis for frequently accessed events
- **Queuing**: Bull/RabbitMQ for async operations
- **File Storage**: S3 for QR code images
- **Analytics**: BigQuery or DataDog
- **Monitoring**: Sentry for error tracking

## 🧪 Testing

### Manual Testing
```bash
# Test registration
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"user@test.com","password":"pass123","name":"Test User"}'

# Test login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@events.com","password":"password"}'

# Get events
curl http://localhost:5000/api/events
```

### Automated Testing
```bash
# Add Jest and Supertest
npm install --save-dev jest supertest

# Create tests/api.test.js for endpoint testing
# Create tests/booking.test.js for business logic
npm test
```

## 📦 Deployment

### Local/Development
```bash
npm start
# Access at http://localhost:5000
```

### Docker Deployment
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

```bash
docker build -t eventhub .
docker run -p 5000:5000 eventhub
```

### Heroku Deployment
```bash
heroku login
heroku create my-event-hub
git push heroku main
heroku logs --tail
```

### AWS Deployment
- **Compute**: EC2 or ECS
- **Database**: RDS PostgreSQL (migrate from SQLite)
- **Storage**: S3 for QR codes
- **CDN**: CloudFront for static assets
- **Load Balancer**: ALB for scaling

### Environment Variables
```
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret-key
CORS_ORIGIN=https://yourdomain.com
```

## 🐛 Troubleshooting

### Database Issues
```bash
# Reset database
rm events.db
npm start

# Check database
sqlite3 events.db ".tables"
```

### JWT Token Errors
- Ensure token is included in Authorization header: `Bearer <token>`
- Token expires after 24 hours, user must login again
- In production, refresh tokens recommended

### CORS Errors
- Add your frontend domain to CORS whitelist
- Ensure frontend sends credentials in requests

## 📝 Activity Log Examples

```javascript
{
  "action": "USER_REGISTERED",
  "details": {"email": "user@example.com", "name": "John Doe"}
}

{
  "action": "EVENT_CREATED",
  "details": {"title": "Tech Conference 2024", "capacity": 500}
}

{
  "action": "TICKET_BOOKED",
  "details": {"eventName": "Summer Music Festival", "quantity": 3, "price": 449.97}
}

{
  "action": "BOOKING_CANCELLED",
  "details": {"eventName": "Tech Conference", "quantity": 2}
}

{
  "action": "TICKET_SCANNED",
  "details": {"ticketId": "ticket-123", "qrCode": "TICKET-booking-1"}
}
```

## 🎓 Learning Resources

- **Express.js Guide**: https://expressjs.com/
- **SQLite Tutorial**: https://www.sqlite.org/docs.html
- **React Hooks**: https://react.dev/reference/react
- **JWT Basics**: https://jwt.io/introduction
- **QR Codes**: https://github.com/davidshimjs/qrcodejs

## 📄 License

MIT License - Free to use for personal and commercial projects

## 🤝 Contributing

For contributions:
1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📞 Support

For issues and questions:
- Check troubleshooting section above
- Review API endpoint documentation
- Check activity logs for debugging
- Open an issue on GitHub

---

**Built with attention to design, performance, and production readiness** ✨
