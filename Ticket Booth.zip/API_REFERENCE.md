# EventHub API Reference

Complete API endpoint documentation with examples and responses.

---

## Authentication Endpoints

### Register New User
**POST** `/api/auth/register`

Creates a new user account.

**Request:**
```json
{
  "email": "user@example.com",
  "password": "securePassword123",
  "name": "John Doe"
}
```

**Response (201):**
```json
{
  "user": {
    "id": "abc123xyz",
    "email": "user@example.com",
    "name": "John Doe",
    "is_admin": false
  },
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Errors:**
- `400` - Missing required fields
- `409` - Email already registered

---

### Login User
**POST** `/api/auth/login`

Authenticates user and returns JWT token.

**Request:**
```json
{
  "email": "admin@events.com",
  "password": "password"
}
```

**Response (200):**
```json
{
  "user": {
    "id": "admin-001",
    "email": "admin@events.com",
    "name": "Admin User",
    "is_admin": true
  },
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Errors:**
- `400` - Missing email or password
- `401` - Invalid credentials

---

## Event Endpoints

### Get All Events
**GET** `/api/events`

Retrieves list of all upcoming events.

**Response (200):**
```json
[
  {
    "id": "evt-001",
    "title": "Tech Conference 2024",
    "description": "Annual tech conference featuring keynotes from industry leaders",
    "date": "2024-08-15T09:00",
    "location": "Convention Center, NYC",
    "organizer": "TechEvents Inc",
    "price": 99.99,
    "capacity": 500,
    "category": "Conference",
    "tickets_sold": 245,
    "created_by": "admin-001",
    "created_at": "2024-07-01T10:30:00"
  },
  // ... more events
]
```

---

### Get Single Event
**GET** `/api/events/:id`

Retrieves detailed information about a specific event.

**Response (200):**
```json
{
  "id": "evt-001",
  "title": "Tech Conference 2024",
  "description": "Annual tech conference featuring keynotes from industry leaders",
  "date": "2024-08-15T09:00",
  "location": "Convention Center, NYC",
  "organizer": "TechEvents Inc",
  "price": 99.99,
  "capacity": 500,
  "category": "Conference",
  "tickets_sold": 245,
  "created_by": "admin-001",
  "created_at": "2024-07-01T10:30:00"
}
```

**Errors:**
- `404` - Event not found

---

### Create Event (Admin Only)
**POST** `/api/events`

Creates a new event. Requires admin authentication.

**Headers:**
```
Authorization: Bearer {token}
Content-Type: application/json
```

**Request:**
```json
{
  "title": "Web Development Workshop",
  "description": "Learn modern web development practices",
  "date": "2024-09-01T10:00",
  "location": "Tech Hub, San Francisco",
  "organizer": "Dev Academy",
  "price": 79.99,
  "capacity": 100,
  "category": "Workshop"
}
```

**Response (201):**
```json
{
  "id": "evt-003",
  "title": "Web Development Workshop",
  "description": "Learn modern web development practices",
  "date": "2024-09-01T10:00",
  "location": "Tech Hub, San Francisco",
  "organizer": "Dev Academy",
  "price": 79.99,
  "capacity": 100,
  "category": "Workshop",
  "tickets_sold": 0,
  "created_by": "admin-001",
  "created_at": "2024-07-15T14:22:00"
}
```

**Errors:**
- `401` - No token provided
- `403` - Admin access required
- `400` - Missing required fields

---

### Update Event (Admin Only)
**PUT** `/api/events/:id`

Updates event details. Requires admin authentication.

**Headers:**
```
Authorization: Bearer {token}
Content-Type: application/json
```

**Request:**
```json
{
  "title": "Tech Conference 2024 - Updated",
  "price": 109.99,
  "capacity": 600
}
```

**Response (200):**
```json
{
  "id": "evt-001",
  "title": "Tech Conference 2024 - Updated",
  "description": "Annual tech conference featuring keynotes from industry leaders",
  "date": "2024-08-15T09:00",
  "location": "Convention Center, NYC",
  "organizer": "TechEvents Inc",
  "price": 109.99,
  "capacity": 600,
  "category": "Conference",
  "tickets_sold": 245,
  "created_by": "admin-001",
  "created_at": "2024-07-01T10:30:00"
}
```

**Errors:**
- `403` - Admin access required
- `404` - Event not found

---

### Delete Event (Admin Only)
**DELETE** `/api/events/:id`

Deletes an event and all associated bookings. Requires admin authentication.

**Headers:**
```
Authorization: Bearer {token}
```

**Response (200):**
```json
{
  "message": "Event deleted successfully"
}
```

**Errors:**
- `403` - Admin access required
- `404` - Event not found

---

## Booking Endpoints

### Create Booking
**POST** `/api/bookings`

Books tickets for an event. Requires authentication.

**Headers:**
```
Authorization: Bearer {token}
Content-Type: application/json
```

**Request:**
```json
{
  "eventId": "evt-001",
  "quantity": 2
}
```

**Response (201):**
```json
{
  "id": "bkg-abc123",
  "event_id": "evt-001",
  "user_id": "user-001",
  "quantity": 2,
  "total_price": 199.98,
  "booking_date": "2024-07-15T15:45:00",
  "status": "active",
  "tickets": [
    {
      "id": "tkt-001",
      "booking_id": "bkg-abc123",
      "qr_code": "TICKET-bkg-abc123-1",
      "status": "valid",
      "scanned_at": null,
      "created_at": "2024-07-15T15:45:00"
    },
    {
      "id": "tkt-002",
      "booking_id": "bkg-abc123",
      "qr_code": "TICKET-bkg-abc123-2",
      "status": "valid",
      "scanned_at": null,
      "created_at": "2024-07-15T15:45:00"
    }
  ]
}
```

**Errors:**
- `401` - No token provided
- `400` - Missing required fields
- `400` - Not enough tickets available
- `404` - Event not found

---

### Get User Bookings
**GET** `/api/bookings`

Retrieves all bookings for the authenticated user.

**Headers:**
```
Authorization: Bearer {token}
```

**Response (200):**
```json
[
  {
    "id": "bkg-abc123",
    "event_id": "evt-001",
    "user_id": "user-001",
    "quantity": 2,
    "total_price": 199.98,
    "booking_date": "2024-07-15T15:45:00",
    "status": "active",
    "event_title": "Tech Conference 2024",
    "event_date": "2024-08-15T09:00",
    "tickets": [
      {
        "id": "tkt-001",
        "booking_id": "bkg-abc123",
        "qr_code": "TICKET-bkg-abc123-1",
        "status": "valid",
        "scanned_at": null,
        "created_at": "2024-07-15T15:45:00"
      }
      // ... more tickets
    ]
  }
  // ... more bookings
]
```

---

### Get Booking Details
**GET** `/api/bookings/:id`

Retrieves detailed information about a specific booking.

**Headers:**
```
Authorization: Bearer {token}
```

**Response (200):**
```json
{
  "id": "bkg-abc123",
  "event_id": "evt-001",
  "user_id": "user-001",
  "quantity": 2,
  "total_price": 199.98,
  "booking_date": "2024-07-15T15:45:00",
  "status": "active",
  "tickets": [
    {
      "id": "tkt-001",
      "booking_id": "bkg-abc123",
      "qr_code": "TICKET-bkg-abc123-1",
      "status": "valid",
      "scanned_at": null,
      "created_at": "2024-07-15T15:45:00"
    }
    // ... more tickets
  ]
}
```

**Errors:**
- `404` - Booking not found

---

### Cancel Booking
**DELETE** `/api/bookings/:id`

Cancels a booking. Only the booking owner can cancel.

**Headers:**
```
Authorization: Bearer {token}
```

**Response (200):**
```json
{
  "message": "Booking cancelled successfully"
}
```

**Errors:**
- `403` - Unauthorized
- `404` - Booking not found

---

## Ticket & QR Code Endpoints

### Get QR Code
**GET** `/api/tickets/:ticketId/qr`

Generates and returns QR code for a ticket.

**Response (200):**
```json
{
  "qrCode": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAADCCAYAAAA...",
  "ticketCode": "TICKET-bkg-abc123-1"
}
```

**Errors:**
- `404` - Ticket not found

---

### Scan Ticket (Admin Only)
**POST** `/api/tickets/:ticketId/scan`

Marks a ticket as scanned/used at the venue. Requires admin authentication.

**Headers:**
```
Authorization: Bearer {token}
```

**Response (200):**
```json
{
  "message": "Ticket scanned successfully"
}
```

**Errors:**
- `403` - Admin access required
- `404` - Ticket not found

---

## Admin Endpoints

### Get Dashboard Stats
**GET** `/api/admin/stats`

Retrieves overall platform statistics. Requires admin authentication.

**Headers:**
```
Authorization: Bearer {token}
```

**Response (200):**
```json
{
  "totalEvents": 3,
  "totalBookings": 42,
  "totalRevenue": 5234.58,
  "totalUsers": 156
}
```

**Errors:**
- `403` - Admin access required

---

### Get Event Statistics
**GET** `/api/admin/events/:id/stats`

Retrieves statistics for a specific event. Requires admin authentication.

**Headers:**
```
Authorization: Bearer {token}
```

**Response (200):**
```json
{
  "event": {
    "id": "evt-001",
    "title": "Tech Conference 2024",
    "price": 99.99,
    "capacity": 500,
    "tickets_sold": 245
  },
  "bookingStats": {
    "total_bookings": 120,
    "total_tickets": 245,
    "total_revenue": 24497.55
  }
}
```

**Errors:**
- `403` - Admin access required
- `404` - Event not found

---

### Get Activity Log
**GET** `/api/activities`

Retrieves the complete activity/audit log. Requires admin authentication.

**Headers:**
```
Authorization: Bearer {token}
```

**Response (200):**
```json
[
  {
    "id": "act-001",
    "user_id": "user-001",
    "action": "USER_REGISTERED",
    "details": "{\"email\":\"user@example.com\",\"name\":\"John Doe\"}",
    "timestamp": "2024-07-15T10:20:00"
  },
  {
    "id": "act-002",
    "user_id": "user-001",
    "action": "TICKET_BOOKED",
    "details": "{\"eventName\":\"Tech Conference 2024\",\"quantity\":2,\"price\":199.98}",
    "timestamp": "2024-07-15T15:45:00"
  },
  {
    "id": "act-003",
    "user_id": "admin-001",
    "action": "TICKET_SCANNED",
    "details": "{\"ticketId\":\"tkt-001\",\"qrCode\":\"TICKET-bkg-abc123-1\"}",
    "timestamp": "2024-07-15T18:30:00"
  }
  // ... more activities
]
```

**Errors:**
- `403` - Admin access required

---

## Activity Log Action Types

Common actions logged in the activity log:

| Action | Triggered By | Details |
|--------|-------------|---------|
| USER_REGISTERED | New user signup | email, name |
| USER_LOGIN | User login | email |
| USER_LOGOUT | User logout | email |
| EVENT_CREATED | Admin creates event | title, capacity |
| EVENT_UPDATED | Admin updates event | eventId |
| EVENT_DELETED | Admin deletes event | eventId |
| TICKET_BOOKED | User books tickets | eventName, quantity, price |
| BOOKING_CANCELLED | User cancels booking | bookingId, quantity |
| TICKET_SCANNED | Admin scans ticket | ticketId, qrCode |

---

## Error Responses

All error responses follow this format:

```json
{
  "error": "Description of what went wrong"
}
```

### Common HTTP Status Codes

| Code | Meaning | Example |
|------|---------|---------|
| 200 | OK | Request succeeded |
| 201 | Created | Resource created successfully |
| 400 | Bad Request | Missing/invalid fields |
| 401 | Unauthorized | No token or token invalid |
| 403 | Forbidden | No admin access |
| 404 | Not Found | Resource doesn't exist |
| 409 | Conflict | Email already registered |
| 500 | Server Error | Unexpected server error |

---

## Authentication

All protected endpoints require a JWT token in the Authorization header:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Getting a Token:**
1. Register or login to get a token
2. Token expires after 24 hours
3. Include in every protected endpoint request
4. If token invalid, user must login again

---

## Rate Limiting (Recommended)

Recommended rate limits for production:

```
/api/auth/login        - 5 requests per 15 minutes per IP
/api/auth/register     - 3 requests per hour per IP
/api/bookings          - 20 requests per hour per user
/api/events            - 100 requests per hour per user
```

---

## CORS Configuration

**Development:**
```
CORS_ORIGIN=http://localhost:3000
```

**Production:**
```
CORS_ORIGIN=https://yourdomain.com,https://www.yourdomain.com
```

---

## Testing Examples

### Using cURL

```bash
# Login
TOKEN=$(curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@events.com","password":"password"}' \
  | jq -r '.token')

# Get events
curl http://localhost:5000/api/events

# Create booking
curl -X POST http://localhost:5000/api/bookings \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"eventId":"evt-001","quantity":2}'
```

### Using JavaScript/Fetch

```javascript
// Login
const response = await fetch('http://localhost:5000/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'admin@events.com',
    password: 'password'
  })
});

const { token } = await response.json();

// Get events
const events = await fetch('http://localhost:5000/api/events')
  .then(r => r.json());

// Create booking
const booking = await fetch('http://localhost:5000/api/bookings', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    eventId: 'evt-001',
    quantity: 2
  })
}).then(r => r.json());
```

---

**Last Updated:** July 2024
**API Version:** v1
**Base URL:** http://localhost:5000
