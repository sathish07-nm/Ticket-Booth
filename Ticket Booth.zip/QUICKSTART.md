# EventHub Quick Start Guide

Get the event management platform running in 5 minutes.

## Option 1: Backend Only (Node.js Server)

Perfect for API development and testing.

```bash
# 1. Install dependencies
npm install

# 2. Start the server
npm start

# 3. Server is ready!
# Access API: http://localhost:5000
```

**Test the API:**
```bash
# Get all events
curl http://localhost:5000/api/events

# Login as admin
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@events.com","password":"password"}'
```

Demo Login:
- Email: `admin@events.com`
- Password: `password`

## Option 2: Full Stack with React

Complete development setup.

### Step 1: Start Backend
```bash
npm install
npm start
# Backend running on http://localhost:5000
```

### Step 2: Start Frontend (in another terminal)
```bash
# Create a new React project
npx create-react-app frontend
cd frontend

# Install dependencies
npm install react-router-dom axios

# Add proxy to package.json (for API calls)
# "proxy": "http://localhost:5000"

# Copy the React component
# (Paste the EventManagementApp component into src/App.js)

# Start development server
npm start
# Frontend running on http://localhost:3000
```

### Step 3: Use the Application
1. Open http://localhost:3000 in your browser
2. Click "Register" to create a new account
3. Or login with `admin@events.com` / `password`
4. Browse events and book tickets
5. Visit "Admin Dashboard" (if logged in as admin) to create events

## Key Workflows

### Create an Event (Admin)
1. Login as admin@events.com
2. Click "Admin" in navigation
3. Click "+ New Event"
4. Fill in event details:
   - Title, description
   - Date/time
   - Location
   - Price per ticket
   - Total capacity
5. Click "Create Event"

### Book Tickets (Customer)
1. Browse events on home page
2. Click "View & Book →" on any event
3. Select quantity
4. Click "Book Tickets →"
5. Login/register if needed
6. View tickets in "My Bookings" dashboard

### Scan Tickets at Venue (Admin)
1. Go to Admin Dashboard
2. Use "Ticket Scanner" (API endpoint: `POST /api/tickets/:ticketId/scan`)
3. Scan QR code to mark ticket as used

### View Activity Log (Admin)
1. Admin Dashboard → Activity Log section
2. See all user actions with timestamps
3. Export data as needed

## Database

EventHub uses SQLite for persistence.

**Database File**: `events.db` (created automatically)

**Reset Database**:
```bash
rm events.db
npm start
```

**Inspect Database**:
```bash
# Install SQLite CLI
brew install sqlite3  # macOS
sudo apt install sqlite3  # Ubuntu

# Connect to database
sqlite3 events.db

# View tables
.tables

# Query users
SELECT id, email, name, is_admin FROM users;

# Query events with ticket sales
SELECT id, title, price, capacity, tickets_sold FROM events;

# View recent bookings
SELECT * FROM bookings ORDER BY booking_date DESC LIMIT 10;

# Exit
.quit
```

## Environment Variables

Create `.env` file for configuration (optional):

```env
NODE_ENV=development
PORT=5000
CORS_ORIGIN=http://localhost:3000
JWT_SECRET=your-secret-key-here
JWT_EXPIRES_IN=24h
```

Load in server.js:
```javascript
import dotenv from 'dotenv';
dotenv.config();

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
```

Install dotenv:
```bash
npm install dotenv
```

## Production Deployment

### Using Heroku

```bash
# 1. Install Heroku CLI
# https://devcenter.heroku.com/articles/heroku-cli

# 2. Login to Heroku
heroku login

# 3. Create app
heroku create my-event-hub

# 4. Deploy
git push heroku main

# 5. View logs
heroku logs --tail

# 6. Open app
heroku open
```

### Using Docker

```bash
# Build image
docker build -t eventhub:latest .

# Run container
docker run -p 5000:5000 \
  -e NODE_ENV=production \
  -e JWT_SECRET=your-secret \
  eventhub:latest

# Container is accessible at http://localhost:5000
```

### Using Railway

```bash
# 1. Connect GitHub repo to Railway
# 2. Set environment variables in Railway dashboard
# 3. Deploy automatically

# View logs
railway logs
```

## Common Commands

```bash
# Development
npm start              # Start server
npm run dev           # Start with auto-reload (requires nodemon)

# Database
sqlite3 events.db     # Open SQLite CLI
npm run reset-db      # Reset database (add to package.json)

# Testing
curl http://localhost:5000/api/events

# Logs
npm start             # Server logs print to console
tail -f server.log    # If logging to file

# Debugging
NODE_DEBUG=express npm start   # Debug Express
```

## Troubleshooting

### Port Already in Use
```bash
# Change port in server.js or use environment variable
PORT=3001 npm start

# Or kill existing process
lsof -i :5000
kill -9 <PID>
```

### Database Locked
```bash
# SQLite may be locked by another process
rm events.db
npm start
```

### CORS Errors
```javascript
// Update server.js
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));
```

### JWT Token Invalid
- Token expires after 24 hours
- User must login again
- Check token is in Authorization header: `Bearer <token>`

### QR Code Not Generating
- Ensure `qrcode` package is installed: `npm install qrcode`
- Check browser console for errors
- Verify QR code endpoint: `GET /api/tickets/:ticketId/qr`

## Feature Checklist

**User Features:**
- [x] Browse events
- [x] Register/Login
- [x] Book tickets
- [x] View QR code tickets
- [x] Cancel bookings
- [x] Booking history

**Admin Features:**
- [x] Create events
- [x] Edit events
- [x] Delete events
- [x] View dashboard stats
- [x] Scan tickets
- [x] Activity logging
- [x] Event analytics

**Technical:**
- [x] User authentication (JWT)
- [x] Role-based access (admin)
- [x] SQLite database
- [x] QR code generation
- [x] Activity audit log
- [x] Error handling
- [x] CORS support

## Next Steps

1. **Customize Design**: Modify colors and fonts in React styles
2. **Add Features**:
   - Email confirmations
   - Payment integration (Stripe/PayPal)
   - Discount codes
   - Waiting lists
   - Refund management
3. **Scale Up**:
   - Migrate to PostgreSQL
   - Add Redis caching
   - Set up CDN
   - Add monitoring/logging

## Getting Help

- **API Issues**: Check `/api/activities` for error logs
- **Database**: Use `sqlite3` CLI to inspect data
- **React**: Check browser console for errors
- **Authentication**: Verify JWT token format

---

**You're all set!** 🎉 The platform is ready to use.

Questions? Check README.md for detailed documentation.
