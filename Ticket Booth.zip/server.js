import express from 'express';
import sqlite3 from 'sqlite3';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import QRCode from 'qrcode';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============================================================================
// CONFIGURATION
// ============================================================================

const app = express();
const PORT = 5000;
const DB_PATH = './events.db';
const JWT_SECRET = 'your-secret-key-change-in-production';

// Middleware
app.use(cors());
app.use(express.json());

// ============================================================================
// DATABASE INITIALIZATION
// ============================================================================

const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Connected to SQLite database');
    initializeDatabase();
  }
});

const run = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, (err) => {
      if (err) reject(err);
      else resolve();
    });
  });
};

const get = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
};

const all = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
};

const initializeDatabase = async () => {
  try {
    // Users table
    await run(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        is_admin BOOLEAN DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Events table
    await run(`
      CREATE TABLE IF NOT EXISTS events (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        date TEXT NOT NULL,
        location TEXT NOT NULL,
        organizer TEXT NOT NULL,
        price REAL NOT NULL,
        capacity INTEGER NOT NULL,
        category TEXT,
        tickets_sold INTEGER DEFAULT 0,
        created_by TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id)
      )
    `);

    // Bookings table
    await run(`
      CREATE TABLE IF NOT EXISTS bookings (
        id TEXT PRIMARY KEY,
        event_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        total_price REAL NOT NULL,
        booking_date TEXT DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'active',
        FOREIGN KEY (event_id) REFERENCES events(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    `);

    // Tickets table
    await run(`
      CREATE TABLE IF NOT EXISTS tickets (
        id TEXT PRIMARY KEY,
        booking_id TEXT NOT NULL,
        qr_code TEXT UNIQUE NOT NULL,
        status TEXT DEFAULT 'valid',
        scanned_at TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (booking_id) REFERENCES bookings(id)
      )
    `);

    // Activity log table
    await run(`
      CREATE TABLE IF NOT EXISTS activities (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        action TEXT NOT NULL,
        details TEXT,
        timestamp TEXT DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Insert demo admin user if not exists
    const adminExists = await get('SELECT * FROM users WHERE email = ?', ['admin@events.com']);
    if (!adminExists) {
      await run(
        'INSERT INTO users (id, email, password, name, is_admin) VALUES (?, ?, ?, ?, ?)',
        ['admin-001', 'admin@events.com', 'password', 'Admin User', 1]
      );
      console.log('Admin user created: admin@events.com / password');
    }

    // Insert sample events if not exists
    const eventCount = await get('SELECT COUNT(*) as count FROM events');
    if (eventCount.count === 0) {
      const sampleEvents = [
        {
          id: 'evt-001',
          title: 'Tech Conference 2024',
          description: 'Annual tech conference featuring keynotes from industry leaders',
          date: '2024-08-15T09:00',
          location: 'Convention Center, NYC',
          organizer: 'TechEvents Inc',
          price: 99.99,
          capacity: 500,
          category: 'Conference',
        },
        {
          id: 'evt-002',
          title: 'Summer Music Festival',
          description: 'Three days of live music performances',
          date: '2024-07-20T18:00',
          location: 'Central Park, NYC',
          organizer: 'Music Productions',
          price: 149.99,
          capacity: 3000,
          category: 'Music',
        },
        {
          id: 'evt-003',
          title: 'Web Development Workshop',
          description: 'Learn modern web development practices',
          date: '2024-09-01T10:00',
          location: 'Tech Hub, San Francisco',
          organizer: 'Dev Academy',
          price: 79.99,
          capacity: 100,
          category: 'Workshop',
        },
      ];

      for (const event of sampleEvents) {
        await run(
          `INSERT INTO events 
          (id, title, description, date, location, organizer, price, capacity, category, created_by) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            event.id,
            event.title,
            event.description,
            event.date,
            event.location,
            event.organizer,
            event.price,
            event.capacity,
            event.category,
            'admin-001',
          ]
        );
      }
      console.log('Sample events created');
    }

    console.log('Database initialized successfully');
  } catch (err) {
    console.error('Error initializing database:', err);
  }
};

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

const generateId = () => Math.random().toString(36).substr(2, 9);

const generateQRCode = async (data) => {
  try {
    const qrCode = await QRCode.toDataURL(data);
    return qrCode;
  } catch (err) {
    console.error('Error generating QR code:', err);
    return null;
  }
};

const logActivity = async (userId, action, details) => {
  const id = generateId();
  await run(
    'INSERT INTO activities (id, user_id, action, details) VALUES (?, ?, ?, ?)',
    [id, userId || 'anonymous', action, JSON.stringify(details)]
  );
};

// ============================================================================
// AUTHENTICATION MIDDLEWARE
// ============================================================================

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// ============================================================================
// AUTH ROUTES
// ============================================================================

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;

    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const existingUser = await get('SELECT * FROM users WHERE email = ?', [email]);
    if (existingUser) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const userId = generateId();
    await run(
      'INSERT INTO users (id, email, password, name) VALUES (?, ?, ?, ?)',
      [userId, email, password, name]
    );

    await logActivity(userId, 'USER_REGISTERED', { email, name });

    const user = { id: userId, email, name, is_admin: false };
    const token = jwt.sign(user, JWT_SECRET, { expiresIn: '24h' });

    res.status(201).json({ user, token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Missing email or password' });
    }

    const user = await get('SELECT * FROM users WHERE email = ? AND password = ?', [
      email,
      password,
    ]);

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    await logActivity(user.id, 'USER_LOGIN', { email });

    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name, is_admin: user.is_admin },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      user: { id: user.id, email: user.email, name: user.name, is_admin: user.is_admin },
      token,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================================
// EVENTS ROUTES
// ============================================================================

// Get all events
app.get('/api/events', async (req, res) => {
  try {
    const events = await all('SELECT * FROM events ORDER BY date DESC');
    res.json(events);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single event
app.get('/api/events/:id', async (req, res) => {
  try {
    const event = await get('SELECT * FROM events WHERE id = ?', [req.params.id]);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }
    res.json(event);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create event (admin only)
app.post('/api/events', authenticateToken, async (req, res) => {
  try {
    const user = req.user;
    if (!user.is_admin) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const {
      title,
      description,
      date,
      location,
      organizer,
      price,
      capacity,
      category,
    } = req.body;

    const eventId = generateId();
    await run(
      `INSERT INTO events 
      (id, title, description, date, location, organizer, price, capacity, category, created_by) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [eventId, title, description, date, location, organizer, price, capacity, category, user.id]
    );

    await logActivity(user.id, 'EVENT_CREATED', { title, capacity });

    const event = await get('SELECT * FROM events WHERE id = ?', [eventId]);
    res.status(201).json(event);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update event (admin only)
app.put('/api/events/:id', authenticateToken, async (req, res) => {
  try {
    const user = req.user;
    if (!user.is_admin) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const { title, description, date, location, price, capacity, category } = req.body;

    await run(
      `UPDATE events SET title = ?, description = ?, date = ?, location = ?, price = ?, capacity = ?, category = ? WHERE id = ?`,
      [title, description, date, location, price, capacity, category, req.params.id]
    );

    await logActivity(user.id, 'EVENT_UPDATED', { eventId: req.params.id });

    const event = await get('SELECT * FROM events WHERE id = ?', [req.params.id]);
    res.json(event);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete event (admin only)
app.delete('/api/events/:id', authenticateToken, async (req, res) => {
  try {
    const user = req.user;
    if (!user.is_admin) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const event = await get('SELECT * FROM events WHERE id = ?', [req.params.id]);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }

    await run('DELETE FROM bookings WHERE event_id = ?', [req.params.id]);
    await run('DELETE FROM events WHERE id = ?', [req.params.id]);

    await logActivity(user.id, 'EVENT_DELETED', { eventId: req.params.id });

    res.json({ message: 'Event deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================================
// BOOKINGS ROUTES
// ============================================================================

// Book tickets
app.post('/api/bookings', authenticateToken, async (req, res) => {
  try {
    const { eventId, quantity } = req.body;
    const userId = req.user.id;

    if (!eventId || !quantity) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const event = await get('SELECT * FROM events WHERE id = ?', [eventId]);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }

    if (event.tickets_sold + quantity > event.capacity) {
      return res.status(400).json({ error: 'Not enough tickets available' });
    }

    const bookingId = generateId();
    const totalPrice = event.price * quantity;

    await run(
      'INSERT INTO bookings (id, event_id, user_id, quantity, total_price) VALUES (?, ?, ?, ?, ?)',
      [bookingId, eventId, userId, quantity, totalPrice]
    );

    // Create individual tickets with QR codes
    for (let i = 0; i < quantity; i++) {
      const ticketId = generateId();
      const qrCodeData = `TICKET-${bookingId}-${i + 1}`;

      await run(
        'INSERT INTO tickets (id, booking_id, qr_code) VALUES (?, ?, ?)',
        [ticketId, bookingId, qrCodeData]
      );
    }

    // Update event ticket count
    await run('UPDATE events SET tickets_sold = tickets_sold + ? WHERE id = ?', [
      quantity,
      eventId,
    ]);

    await logActivity(userId, 'TICKET_BOOKED', {
      eventId,
      quantity,
      price: totalPrice,
    });

    const booking = await get('SELECT * FROM bookings WHERE id = ?', [bookingId]);
    const tickets = await all('SELECT * FROM tickets WHERE booking_id = ?', [bookingId]);

    res.status(201).json({ ...booking, tickets });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get user bookings
app.get('/api/bookings', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id;
    const bookings = await all(
      `SELECT b.*, e.title as event_title, e.date as event_date 
       FROM bookings b 
       JOIN events e ON b.event_id = e.id 
       WHERE b.user_id = ? 
       ORDER BY b.booking_date DESC`,
      [userId]
    );

    // Get tickets for each booking
    for (let booking of bookings) {
      booking.tickets = await all('SELECT * FROM tickets WHERE booking_id = ?', [booking.id]);
    }

    res.json(bookings);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get booking details
app.get('/api/bookings/:id', authenticateToken, async (req, res) => {
  try {
    const booking = await get('SELECT * FROM bookings WHERE id = ?', [req.params.id]);
    if (!booking) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    const tickets = await all('SELECT * FROM tickets WHERE booking_id = ?', [req.params.id]);
    booking.tickets = tickets;

    res.json(booking);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Cancel booking
app.delete('/api/bookings/:id', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id;
    const booking = await get('SELECT * FROM bookings WHERE id = ?', [req.params.id]);

    if (!booking) {
      return res.status(404).json({ error: 'Booking not found' });
    }

    if (booking.user_id !== userId) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    // Update event ticket count
    await run('UPDATE events SET tickets_sold = tickets_sold - ? WHERE id = ?', [
      booking.quantity,
      booking.event_id,
    ]);

    // Delete tickets
    await run('DELETE FROM tickets WHERE booking_id = ?', [req.params.id]);

    // Delete booking
    await run('DELETE FROM bookings WHERE id = ?', [req.params.id]);

    await logActivity(userId, 'BOOKING_CANCELLED', {
      bookingId: req.params.id,
      quantity: booking.quantity,
    });

    res.json({ message: 'Booking cancelled successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================================
// QR CODE ROUTES
// ============================================================================

// Generate QR code for ticket
app.get('/api/tickets/:ticketId/qr', async (req, res) => {
  try {
    const ticket = await get('SELECT * FROM tickets WHERE id = ?', [req.params.ticketId]);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    const qrCode = await generateQRCode(ticket.qr_code);
    res.json({ qrCode, ticketCode: ticket.qr_code });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Scan ticket (mark as used)
app.post('/api/tickets/:ticketId/scan', authenticateToken, async (req, res) => {
  try {
    const user = req.user;
    if (!user.is_admin) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const ticket = await get('SELECT * FROM tickets WHERE id = ?', [req.params.ticketId]);
    if (!ticket) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    const now = new Date().toISOString();
    await run('UPDATE tickets SET status = ?, scanned_at = ? WHERE id = ?', [
      'used',
      now,
      req.params.ticketId,
    ]);

    await logActivity(user.id, 'TICKET_SCANNED', {
      ticketId: req.params.ticketId,
      qrCode: ticket.qr_code,
    });

    res.json({ message: 'Ticket scanned successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================================
// ACTIVITY LOG ROUTES
// ============================================================================

// Get activity log (admin only)
app.get('/api/activities', authenticateToken, async (req, res) => {
  try {
    const user = req.user;
    if (!user.is_admin) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const activities = await all(
      'SELECT * FROM activities ORDER BY timestamp DESC LIMIT 100'
    );
    res.json(activities);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================================
// ADMIN ROUTES
// ============================================================================

// Get dashboard stats (admin only)
app.get('/api/admin/stats', authenticateToken, async (req, res) => {
  try {
    const user = req.user;
    if (!user.is_admin) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const totalEvents = await get('SELECT COUNT(*) as count FROM events');
    const totalBookings = await get('SELECT COUNT(*) as count FROM bookings');
    const totalRevenue = await get('SELECT SUM(total_price) as total FROM bookings');
    const totalUsers = await get('SELECT COUNT(*) as count FROM users');

    res.json({
      totalEvents: totalEvents.count,
      totalBookings: totalBookings.count,
      totalRevenue: totalRevenue.total || 0,
      totalUsers: totalUsers.count,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get event stats (admin only)
app.get('/api/admin/events/:id/stats', authenticateToken, async (req, res) => {
  try {
    const user = req.user;
    if (!user.is_admin) {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const event = await get('SELECT * FROM events WHERE id = ?', [req.params.id]);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }

    const bookingStats = await get(
      `SELECT COUNT(*) as total_bookings, SUM(quantity) as total_tickets, 
              SUM(total_price) as total_revenue FROM bookings WHERE event_id = ?`,
      [req.params.id]
    );

    res.json({
      event,
      bookingStats,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================================
// ERROR HANDLING
// ============================================================================

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

// ============================================================================
// START SERVER
// ============================================================================

app.listen(PORT, () => {
  console.log(`Event Management Server running on http://localhost:${PORT}`);
  console.log(`Database: ${DB_PATH}`);
  console.log(`\nDemo Login:`);
  console.log(`  Email: admin@events.com`);
  console.log(`  Password: password`);
});
